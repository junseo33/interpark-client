# 인터파크 프론트엔드 프로젝트

- 인터파크 리액트 제작 스터디
- [결과물 보기](https://)

## 프로젝트 설명

### 적용기술

- React
- React Router
- axios
- Swiper

### 기타사항

- 프로젝트 생성

```js
npm run start
```
